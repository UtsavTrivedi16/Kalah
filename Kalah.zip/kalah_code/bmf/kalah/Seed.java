package kalah;

public class Seed extends GameObject {

    public Seed(){
        super();
    }
}
