package kalah;

public class Store extends KalahBuilding {

    public Store(){
        super();
    }

}
